package com.jsh.erp.service.cashier;

import com.alibaba.fastjson.JSONObject;
import com.jsh.erp.datasource.entities.CashierSession;
import com.jsh.erp.datasource.entities.CommissionRule;
import com.jsh.erp.datasource.entities.ServiceItem;
import com.jsh.erp.datasource.entities.ServiceOrder;
import com.jsh.erp.datasource.entities.ServiceOrderItem;
import com.jsh.erp.datasource.mappers.CashierSessionMapper;
import com.jsh.erp.datasource.mappers.CommissionRuleMapper;
import com.jsh.erp.datasource.mappers.ServiceItemMapper;
import com.jsh.erp.datasource.mappers.ServiceOrderItemMapper;
import com.jsh.erp.datasource.mappers.ServiceOrderMapper;
import com.jsh.erp.service.DepotService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

@Service
public class ServiceOrderService {
    @Resource
    private ServiceOrderMapper serviceOrderMapper;

    @Resource
    private CashierSessionMapper cashierSessionMapper;

    @Resource
    private ServiceOrderItemMapper serviceOrderItemMapper;

    @Resource
    private ServiceItemMapper serviceItemMapper;

    @Resource
    private CommissionRuleMapper commissionRuleMapper;

    @Resource
    private DepotService depotService;

    private CashierSession ensureSessionPermission(Long sessionId, Long tenantId) throws Exception {
        CashierSession session = cashierSessionMapper.selectByPrimaryKey(sessionId);
        if (session == null) {
            throw new RuntimeException("会话不存在");
        }
        if (tenantId != null && session.getTenantId() != null && !tenantId.equals(session.getTenantId())) {
            throw new RuntimeException("无权限");
        }
        depotService.ensureCurrentUserDepotPermission(session.getDepotId());
        return session;
    }

    private ServiceOrder ensureOrderPermission(Long orderId, Long tenantId) throws Exception {
        ServiceOrder order = serviceOrderMapper.selectByPrimaryKey(orderId);
        if (order == null) {
            throw new RuntimeException("服务单不存在");
        }
        if (tenantId != null && order.getTenantId() != null && !tenantId.equals(order.getTenantId())) {
            throw new RuntimeException("无权限");
        }
        ensureSessionPermission(order.getSessionId(), tenantId);
        return order;
    }

    public List<ServiceOrder> listBySessionId(Long sessionId, Long tenantId) throws Exception {
        ensureSessionPermission(sessionId, tenantId);
        return serviceOrderMapper.selectBySessionId(sessionId, tenantId);
    }

    public List<ServiceOrderItem> listItemsByOrderId(Long orderId, Long tenantId) throws Exception {
        ensureOrderPermission(orderId, tenantId);
        return serviceOrderItemMapper.selectByOrderId(orderId, tenantId);
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public ServiceOrderItem quickAddItem(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long sessionId = obj.getLong("sessionId");
        Long serviceItemId = obj.getLong("serviceItemId");
        if (sessionId == null || serviceItemId == null) {
            throw new IllegalArgumentException("参数错误");
        }
        CashierSession session = ensureSessionPermission(sessionId, tenantId);
        if (!"OPEN".equalsIgnoreCase(session.getStatus())) {
            throw new IllegalArgumentException("会话已关闭");
        }
        ServiceOrder order = serviceOrderMapper.selectOpenDeskOrder(sessionId, tenantId);
        if (order == null) {
            ServiceOrder create = new ServiceOrder();
            create.setSessionId(sessionId);
            create.setTechnicianId(null);
            create.setStatus("OPEN");
            create.setCreatedTime(new Date());
            create.setTenantId(tenantId);
            create.setRemark("收银台");
            create.setDeleteFlag("0");
            serviceOrderMapper.insertSelective(create);
            order = create;
        }
        JSONObject add = new JSONObject();
        add.put("serviceOrderId", order.getId());
        add.put("serviceItemId", serviceItemId);
        add.put("qty", obj.getBigDecimal("qty"));
        return addItem(add, tenantId, request);
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public ServiceOrder createOrder(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long sessionId = obj.getLong("sessionId");
        Long technicianId = obj.getLong("technicianId");
        String remark = obj.getString("remark");
        CashierSession session = ensureSessionPermission(sessionId, tenantId);
        if (!"OPEN".equalsIgnoreCase(session.getStatus())) {
            throw new IllegalArgumentException("会话已关闭");
        }

        ServiceOrder order = new ServiceOrder();
        order.setSessionId(sessionId);
        order.setTechnicianId(technicianId);
        order.setStatus("OPEN");
        order.setCreatedTime(new Date());
        order.setTenantId(tenantId);
        order.setRemark(remark);
        order.setDeleteFlag("0");
        serviceOrderMapper.insertSelective(order);
        return order;
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public ServiceOrderItem addItem(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long serviceOrderId = obj.getLong("serviceOrderId");
        Long serviceItemId = obj.getLong("serviceItemId");
        BigDecimal qty = obj.getBigDecimal("qty");
        if (qty == null) {
            qty = BigDecimal.ONE;
        }
        ServiceOrder order = ensureOrderPermission(serviceOrderId, tenantId);
        if (order.getStatus() != null && !"OPEN".equalsIgnoreCase(order.getStatus())) {
            throw new IllegalArgumentException("服务单已完成");
        }
        ServiceItem serviceItem = serviceItemMapper.selectByPrimaryKey(serviceItemId);
        BigDecimal unitPrice = serviceItem == null || serviceItem.getPrice() == null ? BigDecimal.ZERO : serviceItem.getPrice();
        BigDecimal amount = unitPrice.multiply(qty).setScale(6, RoundingMode.HALF_UP);

        ServiceOrderItem item = new ServiceOrderItem();
        item.setServiceOrderId(serviceOrderId);
        item.setServiceItemId(serviceItemId);
        item.setQty(qty);
        item.setUnitPrice(unitPrice);
        item.setAmount(amount);
        item.setCommissionAmount(BigDecimal.ZERO);
        item.setTenantId(tenantId);
        item.setDeleteFlag("0");
        serviceOrderItemMapper.insertSelective(item);
        return item;
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public int updateItemQty(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long id = obj.getLong("id");
        BigDecimal qty = obj.getBigDecimal("qty");
        if (id == null || qty == null || qty.compareTo(BigDecimal.ZERO) <= 0) {
            return 0;
        }
        ServiceOrderItem db = serviceOrderItemMapper.selectByPrimaryKey(id);
        if (db == null) {
            return 0;
        }
        if (tenantId != null && db.getTenantId() != null && !tenantId.equals(db.getTenantId())) {
            return 0;
        }
        ensureOrderPermission(db.getServiceOrderId(), tenantId);
        BigDecimal unitPrice = db.getUnitPrice();
        if (unitPrice == null && db.getServiceItemId() != null) {
            ServiceItem serviceItem = serviceItemMapper.selectByPrimaryKey(db.getServiceItemId());
            unitPrice = serviceItem == null || serviceItem.getPrice() == null ? BigDecimal.ZERO : serviceItem.getPrice();
        }
        BigDecimal amount = (unitPrice == null ? BigDecimal.ZERO : unitPrice).multiply(qty).setScale(6, RoundingMode.HALF_UP);
        ServiceOrderItem update = new ServiceOrderItem();
        update.setId(id);
        update.setTenantId(tenantId);
        update.setQty(qty);
        update.setUnitPrice(unitPrice);
        update.setAmount(amount);
        return serviceOrderItemMapper.updateByPrimaryKeySelective(update);
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public int deleteItem(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long id = obj.getLong("id");
        if (id == null) {
            return 0;
        }
        ServiceOrderItem db = serviceOrderItemMapper.selectByPrimaryKey(id);
        if (db == null) {
            return 0;
        }
        if (tenantId != null && db.getTenantId() != null && !tenantId.equals(db.getTenantId())) {
            return 0;
        }
        ensureOrderPermission(db.getServiceOrderId(), tenantId);
        ServiceOrderItem update = new ServiceOrderItem();
        update.setId(id);
        update.setTenantId(tenantId);
        update.setDeleteFlag("1");
        return serviceOrderItemMapper.updateByPrimaryKeySelective(update);
    }

    @Transactional(value = "transactionManager", rollbackFor = Exception.class)
    public int finishOrder(JSONObject obj, Long tenantId, HttpServletRequest request) throws Exception {
        Long serviceOrderId = obj.getLong("serviceOrderId");
        ServiceOrder order = ensureOrderPermission(serviceOrderId, tenantId);
        List<ServiceOrderItem> items = serviceOrderItemMapper.selectByOrderId(serviceOrderId, tenantId);
        List<CommissionRule> rules = commissionRuleMapper.selectEnabledRules(tenantId);
        for (ServiceOrderItem item : items) {
            BigDecimal commissionAmount = calcCommissionAmount(rules, order.getTechnicianId(), item.getServiceItemId(), item.getQty(), item.getAmount());
            ServiceOrderItem update = new ServiceOrderItem();
            update.setId(item.getId());
            update.setTenantId(tenantId);
            update.setCommissionAmount(commissionAmount);
            serviceOrderItemMapper.updateByPrimaryKeySelective(update);
        }
        ServiceOrder updateOrder = new ServiceOrder();
        updateOrder.setId(serviceOrderId);
        updateOrder.setTenantId(tenantId);
        updateOrder.setStatus("FINISHED");
        updateOrder.setFinishedTime(new Date());
        return serviceOrderMapper.updateByPrimaryKeySelective(updateOrder);
    }

    private BigDecimal calcCommissionAmount(List<CommissionRule> rules, Long technicianId, Long serviceItemId, BigDecimal qty, BigDecimal amount) {
        CommissionRule rule = findRule(rules, technicianId, serviceItemId);
        if (rule == null || rule.getCommissionValue() == null || rule.getCommissionType() == null) {
            return BigDecimal.ZERO;
        }
        if ("PERCENT".equalsIgnoreCase(rule.getCommissionType())) {
            return amount.multiply(rule.getCommissionValue())
                    .divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP);
        }
        if ("FIXED".equalsIgnoreCase(rule.getCommissionType())) {
            BigDecimal q = qty == null ? BigDecimal.ONE : qty;
            return q.multiply(rule.getCommissionValue()).setScale(6, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    private CommissionRule findRule(List<CommissionRule> rules, Long technicianId, Long serviceItemId) {
        if (rules == null || rules.isEmpty()) {
            return null;
        }
        for (CommissionRule rule : rules) {
            if (!"TECHNICIAN_ITEM".equalsIgnoreCase(rule.getRuleScope())) {
                continue;
            }
            if (technicianId != null && technicianId.equals(rule.getTechnicianId())
                    && serviceItemId != null && serviceItemId.equals(rule.getServiceItemId())) {
                return rule;
            }
        }
        for (CommissionRule rule : rules) {
            if (!"SERVICE_ITEM".equalsIgnoreCase(rule.getRuleScope())) {
                continue;
            }
            if (serviceItemId != null && serviceItemId.equals(rule.getServiceItemId())) {
                return rule;
            }
        }
        for (CommissionRule rule : rules) {
            if (!"TECHNICIAN_ALL".equalsIgnoreCase(rule.getRuleScope())) {
                continue;
            }
            if (technicianId != null && technicianId.equals(rule.getTechnicianId())) {
                return rule;
            }
        }
        return null;
    }
}
